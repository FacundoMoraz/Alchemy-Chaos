// Reemplazo completo del código para usar imágenes en lugar de círculos
const config = {
  type: Phaser.AUTO,
  width: 640,
  height: 960,
  backgroundColor: "#ffffff",
  physics: {
    default: "matter",
    matter: {
      gravity: { y: 1.4 },
      debug: false,
    },
  },
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  scene: {
    preload,
    create,
    update,
  },
};

const game = new Phaser.Game(config);

let objects = [];
let types = [
  { key: "hueso", radius: 28, value: 10, scale: 0.07 },
  { key: "corazon", radius: 48, value: 20, scale: 0.12 },
  { key: "hongo", radius: 68, value: 30, scale: 0.17 },
  { key: "rosa", radius: 88, value: 40, scale: 0.22 },
  { key: "mariposa", radius: 108, value: 50, scale: 0.27 },
  { key: "lagrima", radius: 128, value: 60, scale: 0.32 },
  { key: "pluma", radius: 148, value: 70, scale: 0.37 },
  { key: "libro", radius: 166, value: 80, scale: 0.42 },
  { key: "cristal", radius: 196, value: 90, scale: 0.47 },
  { key: "luna", radius: 216, value: 100, scale: 0.52 },
  { key: "sol", radius: 236, value: 120, scale: 0.57 },
  { key: "runa", radius: 250, value: 140, scale: 0.62 },
];

let score = 0;
let gameOverText, scoreText, restartText;
let gameOver = false;
let dropPreview;
let currentDropType;
let dropX = config.width / 2;
let dropLineY = config.height - 840;
let dropCooldown = false;
const dropCooldownTime = 600;
const gameOverDelay = 10000;

function preload() {
  this.load.image("llave", "ball/Llave.png");
  this.load.image("calavera", "ball/calavera.png");
  this.load.image("corazon", "ball/corazon.png");
  this.load.image("cristal", "ball/cristal.png");
  this.load.image("daga", "ball/daga.png");
  this.load.image("estrella", "ball/estrella.png");
  this.load.image("hongo", "ball/hongo.png");
  this.load.image("hueso", "ball/Hueso.png");
  this.load.image("lagrima", "ball/lagrima.png");
  this.load.image("libro", "ball/libro.png");
  this.load.image("reloj", "ball/reloj.png");
  this.load.image("rosa", "ball/rosa.png");
  this.load.image("runa", "ball/runa.png");
  this.load.image("sol", "ball/sol.png");
  this.load.image("luna", "ball/luna.png");
  this.load.image("mariposa", "ball/mariposa.png");
  this.load.image("pluma", "ball/pluma.png");
  this.load.image("caldero", "ball/caldero.png");
}

function create() {
  let isTouching = false;

  const scene = this;
  gameOver = false;
  score = 0;
  objects = [];

  const width = config.width;
  const height = config.height;
  const thickness = 5;
  const offsetY = 100;

  // Crear el caldero visual
  const caldero = scene.add.image(width / 2, height - 400, "caldero");
  caldero.setScale(0.33, 0.4);
  caldero.setDepth(-1);

  // Crear límites físicos del caldero
  const calderoBounds = {
    width: caldero.displayWidth,
    height: caldero.displayHeight,
    x: caldero.x,
    y: caldero.y,
  };

  // Parámetros base
  const wallThickness = 10;
  const segmentHeight = 400; // Puedes aumentar esto para alargar las paredes
  const offsetX = calderoBounds.width * 0.35;
  const cx = calderoBounds.x;
  const cy = calderoBounds.y;

  // === PARED IZQUIERDA ===
  scene.matter.add.rectangle(
    cx - offsetX + -60,
    cy - -160,
    wallThickness,
    segmentHeight,
    {
      isStatic: true,
      angle: Phaser.Math.DegToRad(-18),
    }
  );

  scene.matter.add.rectangle(
    cx - offsetX + -75,
    cy - 60,
    wallThickness,
    segmentHeight,
    {
      isStatic: true,
      angle: Phaser.Math.DegToRad(0),
    }
  );

  scene.matter.add.rectangle(
    cx - offsetX + -70,
    cy + -300,
    wallThickness,
    segmentHeight - 100,
    {
      isStatic: true,
      angle: Phaser.Math.DegToRad(15),
    }
  );

  // === PARED DERECHA ===
  scene.matter.add.rectangle(
    cx + offsetX + 55,
    cy - -160,
    wallThickness,
    segmentHeight,
    {
      isStatic: true,
      angle: Phaser.Math.DegToRad(18),
    }
  );

  scene.matter.add.rectangle(
    cx + offsetX - -75,
    cy - 60,
    wallThickness,
    segmentHeight,
    {
      isStatic: true,
      angle: Phaser.Math.DegToRad(0),
    }
  );

  scene.matter.add.rectangle(
    cx + offsetX - -58,
    cy + -300,
    wallThickness,
    segmentHeight - 100,
    {
      isStatic: true,
      angle: Phaser.Math.DegToRad(-15),
    }
  );

  // Suelo del caldero
  scene.matter.add.rectangle(
    calderoBounds.x,
    calderoBounds.y + calderoBounds.height * 0.35,
    calderoBounds.width * 0.8,
    10,
    { isStatic: true }
  );

  const redLine = scene.add.graphics({
    lineStyle: { width: 2, color: 0xff0000 },
  });
  redLine.strokeLineShape(new Phaser.Geom.Line(0, dropLineY, width, dropLineY));

  const panel = scene.add.rectangle(width / 2, 90, 280, 100, 0xffffff, 0.9);
  panel.setStrokeStyle(2, 0x000000).setVisible(false);

  gameOverText = scene.add
    .text(width / 2, 60, "¡Has perdido!", { fontSize: "24px", color: "#000" })
    .setOrigin(0.5)
    .setVisible(false);
  scoreText = scene.add
    .text(width / 2, 90, "Puntos: 0", { fontSize: "20px", color: "#000" })
    .setOrigin(0.5)
    .setVisible(false);
  restartText = scene.add
    .text(width / 2, 115, "Presiona para reiniciar", {
      fontSize: "16px",
      color: "#666",
    })
    .setOrigin(0.5)
    .setVisible(false);

  panel.setDepth(1);
  gameOverText.setDepth(2);
  scoreText.setDepth(2);
  restartText.setDepth(2);

  currentDropType = getWeightedRandomType();

  dropPreview = scene.add
    .image(dropX, offsetY - 20, currentDropType.key)
    .setScale(currentDropType.scale);

  // Mover preview mientras se mantiene presionado y se mueve el dedo
  scene.input.on("pointermove", (pointer) => {
    if (isTouching) {
      dropX = Phaser.Math.Clamp(pointer.x, 85, config.width - 85);
      dropPreview.x = dropX;
    }
  });

  // Al tocar la pantalla: iniciar seguimiento del dedo
  scene.input.on("pointerdown", (pointer) => {
    if (gameOver) {
      scene.scene.restart();
    } else if (!dropCooldown) {
      isTouching = true; // Comenzar a seguir el dedo
      dropX = Phaser.Math.Clamp(pointer.x, 85, config.width - 85);
      dropPreview.x = dropX;
    }
  });

  // Al soltar el dedo: soltar el objeto en la posición actual del dedo (con Y fija)
  scene.input.on("pointerup", (pointer) => {
    if (isTouching && !dropCooldown) {
      dropObject(scene, dropX); // Crear y soltar objeto en dropX
      dropCooldown = true; // Evitar spamear objetos
      setTimeout(() => (dropCooldown = false), dropCooldownTime);
    }
    isTouching = false; // Dejar de seguir el dedo
  });

  scene.matter.world.on("collisionstart", (event) => {
    for (let pair of event.pairs) {
      const a = pair.bodyA;
      const b = pair.bodyB;
      const objA = objects.find((o) => o.body === a);
      const objB = objects.find((o) => o.body === b);

      if (!objA || !objB || objA.key !== objB.key || objA.level !== objB.level)
        continue;

      const nextLevel = objA.level + 1;
      if (nextLevel >= types.length) continue;

      const newX = (objA.sprite.x + objB.sprite.x) / 2;
      const newY = (objA.sprite.y + objB.sprite.y) / 2;

      scene.matter.world.remove(objA.body);
      scene.matter.world.remove(objB.body);
      objA.sprite.destroy();
      objB.sprite.destroy();
      objects = objects.filter((o) => o !== objA && o !== objB);

      const nextType = types[nextLevel];

      const radius = nextType.radius;
      const scale = nextType.scale;

      const newSprite = scene.add
        .image(newX, newY, nextType.key)
        .setScale(scale);
      const circleBody = scene.matter.bodies.circle(newX, newY, radius, {
        restitution: 0,
        friction: 0.05,
      });
      scene.matter.add
        .gameObject(newSprite)
        .setExistingBody(circleBody)
        .setOrigin(0.5);

      newSprite.setData("dangerTimer", null);

      objects.push({
        sprite: newSprite,
        body: circleBody,
        key: nextType.key,
        level: nextLevel,
      });

      score += nextType.value;
      scoreText.setText("Puntos: " + score);
    }
  });
}

function getWeightedRandomType() {
  const options = types.slice(0, 3); // Los 3 más pequeños
  const weights = [0.6, 0.3, 0.1]; // Probabilidades correspondientes

  const rand = Math.random();
  let acc = 0;

  for (let i = 0; i < options.length; i++) {
    acc += weights[i];
    if (rand <= acc) {
      return options[i];
    }
  }

  return options[0]; // fallback por si acaso
}

function dropObject(scene, x) {
  const type = currentDropType;
  const y = 40;

  const radius = type.radius;

  const sprite = scene.add.image(x, y, type.key).setScale(type.scale);
  const circleBody = scene.matter.bodies.circle(x, y, radius, {
    restitution: 0,
    friction: 0.1,
    frictionAir: 0.02,
    mass: 1,
  });

  scene.matter.add
    .gameObject(sprite)
    .setExistingBody(circleBody)
    .setOrigin(0.5);

  sprite.setData("dangerTimer", null);

  objects.push({
    sprite: sprite,
    body: circleBody,
    key: type.key,
    level: types.findIndex((t) => t.key === type.key),
  });

  // Selección ponderada entre los 3 más pequeños
  const smallestThree = types.slice(0, 3); // Índices 0, 1, 2
  const weights = [0.6, 0.3, 0.1];
  const rand = Math.random();
  let acc = 0;
  for (let i = 0; i < smallestThree.length; i++) {
    acc += weights[i];
    if (rand <= acc) {
      currentDropType = smallestThree[i];
      break;
    }
  }
  dropPreview.setTexture(currentDropType.key);
  dropPreview.setScale(currentDropType.scale);
}

function update() {
  if (gameOver) return;
  for (let obj of objects) {
    const sprite = obj.sprite;
    const timer = sprite.getData("dangerTimer");
    const isDanger = sprite.y < dropLineY;

    if (isDanger && timer === null) {
      const t = setTimeout(() => {
        if (!gameOver) showGameOver(this);
      }, gameOverDelay);
      sprite.setData("dangerTimer", t);
    } else if (!isDanger && timer !== null) {
      clearTimeout(timer);
      sprite.setData("dangerTimer", null);
    }
  }
}

function showGameOver(scene) {
  if (gameOver) return;
  gameOver = true;
  gameOverText.setVisible(true);
  scoreText.setText("Puntos: " + score).setVisible(true);
  restartText.setVisible(true);
}
